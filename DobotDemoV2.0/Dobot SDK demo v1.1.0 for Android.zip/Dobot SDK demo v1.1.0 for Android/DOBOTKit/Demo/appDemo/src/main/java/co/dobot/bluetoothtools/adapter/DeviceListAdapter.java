package co.dobot.bluetoothtools.adapter;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import co.dobot.bluetoothtools.R;
import co.dobot.magicain.client.DobotMessageClient;
import co.dobot.magicain.message.DobotMessage;

/**
 * Created by x on 2018/1/20.
 */

public class DeviceListAdapter extends RecyclerView.Adapter<DeviceListAdapter.DeviceHolder> {

    public List<BluetoothDevice> devices;
    public Context context;
    public ProgressDialog dialog;
    public DeviceListAdapter(Context context,HashSet<BluetoothDevice> devices) {
        this.context=context;
        this.devices=new ArrayList<>(devices);
    }

    public List<BluetoothDevice> getDevices() {
        return devices;
    }

    public void setDevices(HashSet<BluetoothDevice> devices) {
        this.devices=new ArrayList<>(devices);
    }

    public void setDialogDismiss(){
        if (dialog!=null)
            dialog.dismiss();
    }

    @Override
    public DeviceHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        DeviceHolder holder=new DeviceHolder(LayoutInflater.from(context).inflate(R.layout.content_device_list,parent,false));
        return holder;
    }

    @Override
    public void onBindViewHolder(DeviceHolder holder, final int position) {
        holder.device_name.setText(devices.get(position).getName());
        holder.device_address.setText(devices.get(position).getAddress());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog=new AlertDialog.Builder(context)
                        .setTitle("连接蓝牙设备")
                        .setMessage("是否连接此蓝牙设备？")
                        .setPositiveButton("是", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                DeviceListAdapter.this.dialog=ProgressDialog.show(context,"连接蓝牙设备","正在连接此设备...",true,false);
                                DobotMessageClient.Instance().connectDevice(devices.get(position));
                            }
                        })
                        .setNegativeButton("否", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                               dialog.dismiss();
                            }
                        })
                        .show();


            }
        });
    }

    @Override
    public int getItemCount() {
        return devices.size();
    }

    public class DeviceHolder extends RecyclerView.ViewHolder
    {
        LinearLayout layout;
        TextView device_name;
        TextView device_address;
        public DeviceHolder(View itemView) {
            super(itemView);
            layout=(LinearLayout)itemView.findViewById(R.id.device_layout);
            device_name=(TextView)itemView.findViewById(R.id.device_name);
            device_address=(TextView)itemView.findViewById(R.id.device_address);
        }
    }
}
