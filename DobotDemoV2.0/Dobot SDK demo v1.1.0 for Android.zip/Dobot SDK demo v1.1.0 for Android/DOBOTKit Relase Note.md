#DOBOTKit Relase Note


##version:1.1.0 date:2018/5/17
**Note:**

* 重构Magician Android蓝牙SDK
* 重新实现所有指令
* 重新编写demo工程